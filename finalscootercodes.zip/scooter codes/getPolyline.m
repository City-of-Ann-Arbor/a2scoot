function [polyline] = getPolyline(initialInput, finalInput)
% takes initial and final addresses and outputs their place IDs via google
% place search api 
% https://developers.google.com/maps/documentation/places/web-service/search#FindPlaceRequests

%% Check parameters 
%prompt_1 = 'Enter address 1'; 
%initialInput = input(prompt_1, 's'); % makes sure input is a string
initialInput = regexprep(initialInput, ' ', '%'); % replaces space with & 
inputType = '&inputtype=textquery';
key = 'AIzaSyD2N0YHKRMJtFaXna3Orj4TPy97jD2NJFM';
locationBias = '&locationbias=circle:500@42.2808,83.7430' ;
%centered at ann arbor's coordinates with radius of 500 m; doesn't work if
%user's ip address is not in AA, so you need city and state if so

website = 'https://maps.googleapis.com/maps/api/place/findplacefromtext/json?input=';
url = [website, initialInput, inputType, locationBias, key];
str = urlread(url);
str;
data = jsondecode(str);

%% Parse results
status = data.status;
switch status
case 'OK'
  initialPlaceID = [data.candidates.place_id];
case 'INVALID_REQUEST'
  error('Google Maps API request was malformed or Invalid Resolution');
case 'OVER_QUERY_LIMIT'
  error('Google Maps API requestor has exceeded quota');
case 'REQUEST_DENIED'
  error('Google Maps API did not complete the request (invalid sensor parameter?)');
case 'UNKNOWN_ERROR'
  error('Google Maps API: an unknown error.');
end
%% Repeat for address 2 
%prompt_2 = 'Enter address 2'; 
%finalInput = input(prompt_2, 's'); % makes sure input is a string
finalInput = regexprep(finalInput, ' ', '%'); % replaces space with & 

inputType = '&inputtype=textquery';

locationBias = '&locationbias=circle:500@42.2808,83.7430' 

website = 'https://maps.googleapis.com/maps/api/place/findplacefromtext/json?input=';
url = [website, finalInput, inputType, locationBias, key];
str2 = urlread(url);
str2;
data2 = jsondecode(str2);

%% Parse results
status = data2.status;
switch status
case 'OK'
  finalPlaceID = [data2.candidates.place_id];
case 'INVALID_REQUEST'
  error('Google Maps API request was malformed or Invalid Resolution');
case 'OVER_QUERY_LIMIT'
  error('Google Maps API requestor has exceeded quota');
case 'REQUEST_DENIED'
  error('Google Maps API did not complete the request (invalid sensor parameter?)');
case 'UNKNOWN_ERROR'
  error('Google Maps API: an unknown error.');
end

%% Get directions 
% uses intial and final place IDs to get the directions in an encoded
% polyline
directionSite = 'https://maps.googleapis.com/maps/api/directions/json?'
origin = 'origin=place_id:'
destination = '&destination=place_id:'
travelMode = '&mode=transit'
url = [directionSite, origin, initialPlaceID, destination, finalPlaceID, travelMode, key]
str3 = urlread(url);
str3;
data3 = jsondecode(str3);
polyline = data3.routes.overview_polyline.points
distanceTransit = 0;
%% for transit, get the distance of the trip that is done on the bus to multiply w emissions
for routeStep = 1:length(data3.routes.legs.steps)
    if strcmpi(data3.routes.legs.steps{routeStep, 1}.travel_mode, 'TRANSIT')
        distString = erase(data3.routes.legs.steps{routeStep, 1}.distance.text, " mi"); 
        distanceTransit = distanceTransit + str2num(distString);
    end
end