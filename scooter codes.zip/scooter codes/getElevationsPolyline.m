function [elevations, resolution, latitudes, longitudes] = getElevationsPolyline(polyline, varargin)

%% process varargin
keyStr = '';
if nargin>2
  p = inputParser;
  p.addParameter('key', '', @ischar)
  p.FunctionName = 'getElevations';
  p.parse(varargin{:})
  results = p.Results;
  if ~isempty(results.key)
    keyStr = sprintf('&key=%s', results.key);
  end
end

%% Query Google
%path = sprintf('%9.6f,%9.6f|%9.6f,%9.6f&samples=%d',latitude1,longitude1,latitude2,longitude2,resolution);

%% create query string and run a query
website = 'https://maps.googleapis.com/maps/api/elevation/json?locations=enc:';
url = [website, polyline, keyStr];
str = urlread(url);
str;
data = jsondecode(str);

%% Parse results
%elevations  = NaN(length(resolution));
% resolution = data.results.resolution;
% latitudes = NaN(length(resolution));
% longitudes = NaN(length(resolution));
format long
status = data.status;
switch status
case 'OK'
  elevations = [data.results.elevation];
  
  if nargout>1
   resolution = [data.results.resolution];
  end
  
  if nargout>2
      latitudes = NaN(size(resolution));
      for lat_column = 1:length(resolution)
        latitudes(lat_column) = [data.results(lat_column).location.lat];
      end
  end
  
  if nargout>3
      longitudes = NaN(size(resolution));
      for lng_column = 1:length(resolution)
        longitudes(lng_column) = [data.results(lng_column).location.lng];
      end
  end

case 'INVALID_REQUEST'
  error('Google Maps API request was malformed or Invalid Resolution');
case 'OVER_QUERY_LIMIT'
  error('Google Maps API requestor has exceeded quota');
case 'REQUEST_DENIED'
  error('Google Maps API did not complete the request (invalid sensor parameter?)');
case 'UNKNOWN_ERROR'
  error('Google Maps API: an unknown error.');
end