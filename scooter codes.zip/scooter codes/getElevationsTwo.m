function [elevation, resolution] = getElevationsTwo(latitude, longitude, varargin)
%GETELEVATIONS queries Google Maps API webservice for ground elevations.
%
%   elevation = GETELEVATIONS(latitude, longitude) returns ground 
%   elevation for latitude and longitude arrays.
%
%   [elevation, resolution] = getElevations(latitude, longitude, ...
%     'key', 'AIzaSyCuN8tjAVEaXorgNjS1tDiVC-oc0QBJoYc' );
%   is an example of a call passing additional attributes to Google Maps 
%   API webservice, and capturing also the resolution of the data. 
%   See https://developers.google.com/maps/documentation/elevation/
%   for details.
%
% EXAMPLE:


%
% Author: Jarek Tuszynski (jaroslaw.w.tuszynski@leidos.com)
% License: BSD (Berkeley Software Distribution)
% Documentation: https://developers.google.com/maps/documentation/elevation/

%% process varargin
keyStr = '';
if nargin>2
  p = inputParser;
  p.addParameter('key', '', @ischar)
  p.FunctionName = 'getElevations';
  p.parse(varargin{:})
  results = p.Results;
  if ~isempty(results.key)
    keyStr = sprintf('&key=%s', results.key);
  end
end

%% Find distance of points
% --Inputs:
%   latlon1: latlon of origin point [lat lon]
%   latlon2: latlon of destination point [lat lon]
%
% --Outputs:
%   d1km: distance calculated by Haversine formula
%   d2km: distance calculated based on Pythagoran theorem
%
% --Example 1, short distance:
%   latlon1=[-43 172];
%   latlon2=[-44  171];
%   [d1km d2km]=distance(latlon1,latlon2)
%   d1km =
%           137.365669065197 (km)
%   d2km =
%           137.368179013869 (km)
%   %d1km approximately equal to d2km
%
% --Example 2, longer distance:
%   latlon1=[-43 172];
%   latlon2=[20  -108];
%   [d1km d2km]=distance(latlon1,latlon2)
%   d1km =
%           10734.8931427602 (km)
%   d2km =
%           31303.4535270825 (km)
%   d1km is significantly different from d2km (d2km is not able to work
%   for longer distances).
%
% First version: 15 Jan 2012
% Updated: 17 June 2012
%--------------------------------------------------------------------------
radius=6371;
lat1=latitude(1)*pi/180;
lat2=latitude(40)*pi/180;
lon1=longitude(1)*pi/180;
lon2=longitude(40)*pi/180;
deltaLat=lat2-lat1;
deltaLon=lon2-lon1;
a=sin((deltaLat)/2)^2 + cos(lat1)*cos(lat2) * sin(deltaLon/2)^2;
c=2*atan2(sqrt(a),sqrt(1-a));
d1km=radius*c;    %Haversine distance
d1m = d1km * 1000; 
%x=deltaLon*cos((lat1+lat2)/2);
%y=deltaLat;
%d2km=radius*sqrt(x*x + y*y); %Pythagoran distance
d1mi = d1km * 0.621371; % 1 km = 0.621371 mi, distance in miles (more accurate for local distances)
%d2mi = d2km * 0.621371; % 1 km = 0.621371 mi, distance in miles 
dist= linspace(0, d1m, 40);
%% Check inputs
nPos = numel(latitude);
assert(nPos>0, 'Latitude and longitude inputs can not be empty')
assert(nPos==numel(longitude), 'Latitude and longitude inputs are not of the same length')
assert(min(latitude(:)) >= -90 && max(latitude(:)) <= 90, 'Latitudes has to be between -90 and 90')
assert(min(longitude(:))>=-180 && max(longitude(:))<=180, 'Longitude has to be between -180 and 180')

%% Query Google
elevation  = zeros(size(latitude))*nan;
resolution = zeros(size(latitude))*nan;
batch = [1:50:nPos nPos+1]; % group in batches of 50
for iBatch=2:length(batch)
  idx = batch(iBatch-1):batch(iBatch)-1;
  coord = '';
  for k = 1:length(idx)
    coord = sprintf('%s%9.6f,%9.6f|',coord,latitude(idx(k)),longitude(idx(k)));
  end
  
  %% create query string and run a query
  website = 'https://maps.googleapis.com/maps/api/elevation/xml?locations=';
  url = [website, coord(1:end-1), keyStr];
  str = urlread(url);
  
  %% Parse results
  status = regexp(str, '<status>([^<]*)<\/status>', 'tokens');
  switch status{1}{1}
    case 'OK'
      res = regexp(str, '<elevation>([^<]*)<\/elevation>', 'tokens');
      elevation(idx) = cellfun(@str2double,res);
      if nargout>1
       res = regexp(str, '<resolution>([^<]*)<\/resolution>', 'tokens');
       resolution(idx) = cellfun(@str2double,res);
      end
    case 'INVALID_REQUEST'
      error('Google Maps API request was malformed');
    case 'OVER_QUERY_LIMIT'
      error('Google Maps API requestor has exceeded quota');
    case 'REQUEST_DENIED'
      error('Google Maps API did not complete the request (invalid sensor parameter?)');
    case 'UNKNOWN_ERROR'
      error('Google Maps API: an unknown error.');
  end
end
